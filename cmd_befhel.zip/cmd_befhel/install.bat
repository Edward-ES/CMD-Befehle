@echo off
chcp 65001 >nul

if "%1" == "-new" (
    goto a
) else (
    goto en
)
:en
if "%1" == "-d" (
    if "%2" == "" (
        echo Fehler: Keine Download-URL angegeben.
        goto ende3
    )
    if "%3" == "" (
        goto ende2
    )
    set download_url=%2
    set save_path=
    goto download
) else (
    goto ende
)


:a
echo -----------------------------------------
echo bay: EdewardES
echo -----------------------------------------
echo eine neue Version von cmd_befhel wird installiert
rem Variablen setzen
set "url=http://www.lennardweb.de/herunterladen/cmd_befhel.zip"
set "zipFile=%USERPROFILE%\Downloads\cmd_befhel.zip"
set "extractTo=%USERPROFILE%\Downloads\cmd_befhel"
set "destDir=C:\Windows\System32\cmd_befhel"

rem Download der ZIP-Datei
echo Lade ZIP-Datei herunter...
powershell -command "Invoke-WebRequest -Uri '%url%' -OutFile '%zipFile%'"

rem Prüfen ob der Download erfolgreich war
if not exist "%zipFile%" (
    echo Download fehlgeschlagen!
    exit /b 1
)

rem ZIP-Datei entpacken
echo Entpacke ZIP-Datei...
powershell -command "Expand-Archive -Path '%zipFile%' -DestinationPath '%extractTo%'"

rem Prüfen ob das Entpacken erfolgreich war
if not exist "%extractTo%" (
    echo Entpacken fehlgeschlagen!
    exit /b 1
)

rem Sicherstellen, dass der Zielordner existiert
if not exist "%destDir%" (
    mkdir "%destDir%"
)

rem Verschieben der entpackten Dateien
echo Verschiebe Dateien nach %destDir%...
move /Y "%extractTo%\*" "%destDir%"

rem Aufräumen
echo Bereinige Downloads-Verzeichnis...
del "%zipFile%"
rd /S /Q "%extractTo%"

echo Vorgang abgeschlossen!
goto ende3

:download
echo -----------------------------------------
echo bay: EdewardES
echo -----------------------------------------
echo wen einer von den punkten unten nicht zuträfen kann kein Download stattfinden!
for %%i in ("%download_url%") do set "filename=%%~nxi"
echo Die Datei heizt: %filename%
echo Download-URL: %download_url%
echo Speicherpfad: %save_path%
powershell -Command "Invoke-WebRequest -Uri '%download_url%' -OutFile '%save_path%\%filename%'"
goto ende3

:ende
echo Fehler: Kein Schlüsselwort (wie z.B. /new, /d,...) angegeben.
goto ende3

:ende2
echo Fehler: Kein Verzeichnis angegeben (wie z.B. C:\Users\User\Documents).
:ende3
