@echo off
echo -----------------------------------
echo bay: EdewardES
echo -----------------------------------
echo Uhr: %time%  Datum: %date%
echo -----------------------------------