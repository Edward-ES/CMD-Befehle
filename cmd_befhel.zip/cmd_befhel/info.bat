@echo off
chcp 65001 >nul

if "%1" == "-k" (
	goto k
) else (
    if "%1" == "-?" (
		goto ac
	)else (
		goto ab
	) 
)

:ac
echo -----------------------------------------
echo bay: EdewardES
echo -----------------------------------------
echo t			= aktuelle Uhrzeit und Datum.
echo info			= alle Infos über ihrem Computer.
echo info -?			= welche befehle es gibt.
echo info -k			= grafische Oberfläche mit ipconfig
echo install -new		= installiert die neue Version von diesen Scrips.
echo install -d		= damit kann man alle kompatiblen apps und adere Sachen runterladen.
echo ~a                      = Fenster schlissen ein Fenster mit atmen rechte öffnen
echo ~a -e                   = ein Fenster mit atmen rechten öffnen
goto ende

:ab
echo -----------------------------------------
echo bay: EdewardES
echo -----------------------------------------
:aa
set /p a=wollen sie grafische Oberflächen anzeigen lassen[j/n]: 
if /i "%a%" == "j" (goto a)
if /i "%a%" == "n" (goto n)
goto aa


:a
set /p b=befinden wir uns auf ein Laptop oder Tablet[j/n]: 
if /i "%b%" == "j" (goto b) 
if /i "%b%" == "n" (goto c)
goto a

:n
set /p b=befinden wir uns auf ein Laptop oder Tablet[j/n]:  
if /i "%b%" == "j" (goto d) 
if /i "%b%" == "n" (goto e)
goto n


:b
echo ---------------------
echo [Systeminformationen]
echo --------------------- 
systeminfo
hostname
set
echo %PROCESSOR_IDENTIFIER%
echo -----------------------
echo [Hardwareinformationen]
echo ----------------------- 
wmic memorychip get /format
wmic diskdrive get /format
wmic baseboard get /format
wmic bios get /format
echo ----------------------
echo [Netzwerk und Adapter]
echo ---------------------- 
ipconfig /all
getmac
netstat -e
echo -----------------
echo [Weitere Befehle]
echo ----------------- 
tasklist
driverquery
powercfg /batteryreport
echo -----------------------
echo [grafischer Oberfläche]
echo ----------------------- 
msinfo32
goto ende


:c
echo ---------------------
echo [Systeminformationen]
echo --------------------- 
systeminfo
hostname
set
echo %PROCESSOR_IDENTIFIER%
echo -----------------------
echo [Hardwareinformationen]
echo ----------------------- 
wmic memorychip get /format
wmic diskdrive get /format
wmic baseboard get /format
wmic bios get /format
echo ----------------------
echo [Netzwerk und Adapter]
echo ---------------------- 
ipconfig /all
getmac
netstat -e
echo -----------------
echo [Weitere Befehle]
echo ----------------- 
tasklist
driverquery
echo -----------------------
echo [grafischer Oberfläche]
echo -----------------------
msinfo32
goto ende




:d
echo ---------------------
echo [Systeminformationen]
echo --------------------- 
systeminfo
hostname
set
echo %PROCESSOR_IDENTIFIER%
echo -----------------------
echo [Hardwareinformationen]
echo ----------------------- 
wmic memorychip get /format
wmic diskdrive get /format
wmic baseboard get /format
wmic bios get /format
echo ----------------------
echo [Netzwerk und Adapter]
echo ---------------------- 
ipconfig /all
getmac
netstat -e
echo -----------------
echo [Weitere Befehle]
echo ----------------- 
tasklist
driverquery
powercfg /batteryreport
goto ende



:e
echo ---------------------
echo [Systeminformationen]
echo --------------------- 
systeminfo
hostname
set
echo %PROCESSOR_IDENTIFIER%
echo -----------------------
echo [Hardwareinformationen]
echo ----------------------- 
wmic memorychip get /format
wmic diskdrive get /format
wmic baseboard get /format
wmic bios get /format
echo ----------------------
echo [Netzwerk und Adapter]
echo ---------------------- 
ipconfig /all
getmac
netstat -e
echo -----------------
echo [Weitere Befehle]
echo ----------------- 
tasklist
driverquery
goto ende



:k
echo -----------------------------------------
echo bay: EdewardES
echo -----------------------------------------
ipconfig
msinfo32

:ende
