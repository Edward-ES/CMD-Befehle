@echo off

if "%1" == "-e" (
	goto b
) else (
    goto a
)

:a
echo -----------------------------------------
echo bay: EdewardES
echo -----------------------------------------
echo Starte cmd mit Administratorrechten...
powershell -Command "Start-Process cmd -ArgumentList '/k cd %cd%' -Verb RunAs"
exit


:b
echo -----------------------------------------
echo bay: EdewardES
echo -----------------------------------------
echo Starte cmd mit Administratorrechten...
powershell -Command "Start-Process cmd -ArgumentList '/k cd %cd%' -Verb RunAs"