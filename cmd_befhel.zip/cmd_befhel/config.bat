@echo off
chcp 65001 >nul
del "C:\Scripts\config.txt">nul

:a
set /p admin=wollen sie beim starten der cmd eine Mitteilung kriegen ob die cmd als Administrator ausgeführt wurde [j/n]: 
if /i "%admin%" == "j" (goto admin.1)
if /i "%admin%" == "n" (goto admin.2)
goto a



:b
set /p uhr=wollen sie beim starten der cmd oben das Datum und die Uhrzeit anzeigen lasen [j/n]: 
if /i "%uhr%" == "j" (goto uhr.1)
if /i "%uhr%" == "n" (goto uhr.2)
goto b



:c
set /p farbe=soll die Schrift Farbe grün sein [j/n]: 
if /i "%farbe%" == "j" (goto farbe.1)
if /i "%farbe%" == "n" (goto farbe.2)
goto c





:admin.1
echo ------------------->>C:\Scripts\config.txt
echo [Administrator]>>C:\Scripts\config.txt
echo admin=true>>C:\Scripts\config.txt
echo ------------------->>C:\Scripts\config.txt
goto b



:admin.2
echo ------------------->>C:\Scripts\config.txt
echo [Administrator]>>C:\Scripts\config.txt
echo admin=false>>C:\Scripts\config.txt
echo ------------------->>C:\Scripts\config.txt
goto b



:uhr.1
echo [Uhr/Datum]>>C:\Scripts\config.txt
echo uhr/datum=true>>C:\Scripts\config.txt
echo ------------------->>C:\Scripts\config.txt
goto c



:uhr.2
echo [Uhr/Datum]>>C:\Scripts\config.txt
echo uhr/datum=false>>C:\Scripts\config.txt
echo ------------------->>C:\Scripts\config.txt
goto c



:farbe.1
echo [Farbe]>>C:\Scripts\config.txt
echo farbe=true>>C:\Scripts\config.txt
echo ------------------->>C:\Scripts\config.txt
goto ende



:farbe.2
echo [Farbe]>>C:\Scripts\config.txt
echo farbe=false>>C:\Scripts\config.txt
echo ------------------->>C:\Scripts\config.txt
goto ende



:ende